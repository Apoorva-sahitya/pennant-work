package irctc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TrainServlet")
public class trainservlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String fromStation = request.getParameter("from-station");
		String toStation = request.getParameter("to-station");
		System.out.println("From Station: " + fromStation); // Logging the fromStation
		System.out.println("To Station: " + toStation); // Logging the toStation
		connection cn1 = new connection();
		Connection conn1 = null;
		PreparedStatement st1 = null;
		ResultSet rs1 = null;
		PrintWriter pw1 = response.getWriter();
		try {
			conn1 = cn1.connect_to_db("plf_training", "plf_training_admin", "pff123");
			String q1 = "SELECT DISTINCT t.train_name " + "FROM trains_tab_05 t "
					+ "INNER JOIN train_stations_tab_05 ts1 ON t.train_no=ts1.train_no "
					+ "INNER JOIN train_stations_tab_05 ts2 ON t.train_no=ts2.train_no "
					+ "INNER JOIN stations_tab_05 s1 ON ts1.station_id=s1.station_id "
					+ "INNER JOIN stations_tab_05 s2 ON ts2.station_id=s2.station_id " + "WHERE s1.station_name=? "
					+ "AND s2.station_name=? ";
			st1 = conn1.prepareStatement(q1);
			st1.setString(1, fromStation);
			st1.setString(2, toStation);
			rs1 = st1.executeQuery();
			pw1.println("<select id=\"train-list\">");
			pw1.println("<option value=\"\">-- Available Trains --</option>");
			while (rs1.next()) {

				String t_name = rs1.getString("train_name");
				System.out.println("Train Name: " + t_name); // Logging each train name

				pw1.println("<option value=\"" + t_name + "\">" + t_name + "</option>");
			}
			pw1.println("</select>");
		} catch (SQLException e) {
			e.printStackTrace();
			if (pw1 != null) {
				pw1.println("Error fetching train data."); // User-friendly error message
			}
		} finally {
			if (rs1 != null) {
				try {
					rs1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (st1 != null) {
				try {
					st1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn1 != null) {
				try {
					conn1.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			// Close PrintWriter
			if (pw1 != null) {
				pw1.close();
			}
		}

	}
}
