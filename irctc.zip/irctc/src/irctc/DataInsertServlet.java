package irctc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DataInsertServlet")
public class DataInsertServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PrintWriter pw1 = response.getWriter();
		try {

			Class.forName("org.postgresql.Driver");
			connection cn1 = new connection();
			conn1 = cn1.connect_to_db("plf_training", "plf_training_admin", "pff123");

			// Retrieve parameters for the main booking
			String fromStation = request.getParameter("from-station");
			String toStation = request.getParameter("to-station");
			String trainList = request.getParameter("train-list");
			String date = request.getParameter("date");
			String tClass = request.getParameter("tclass");

			// Prepare SQL statement for the main booking
			String sql = "INSERT INTO tkt_booking_186 (ticket_no, from_station, to_station, train_list, date, tclass, tname, gender, age, preference) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn1.prepareStatement(sql);

			// Retrieve parameters for the main passenger
			int mainTicketNo = safeParseInt(request.getParameter("ticketNo"));
			int mainAge = safeParseInt(request.getParameter("age"));

			// Set parameters for the main booking
			pstmt.setInt(1, mainTicketNo);
			pstmt.setString(2, fromStation);
			pstmt.setString(3, toStation);
			pstmt.setString(4, trainList);
			pstmt.setString(5, date);
			pstmt.setString(6, tClass);
			pstmt.setString(7, request.getParameter("name"));
			pstmt.setString(8, request.getParameter("gender"));
			pstmt.setInt(9, mainAge);
			pstmt.setString(10, request.getParameter("preference"));

			pstmt.executeUpdate();

			// Retrieve passenger count
			int passengerCount = safeParseInt(request.getParameter("passengerCount"));

			// Loop through each passenger entry and insert them into the database
			for (int i = 1; i <= passengerCount; i++) {
				String passengerPrefix = "passenger" + i + "_";
				int passengerTicketNo = safeParseInt(request.getParameter(passengerPrefix + "ticketNo"));
				int passengerAge = safeParseInt(request.getParameter(passengerPrefix + "age"));

				pstmt.setInt(1, passengerTicketNo); // Note: This should be index 1, as we're reusing pstmt
				pstmt.setString(2, fromStation);
				pstmt.setString(3, toStation);
				pstmt.setString(4, trainList);
				pstmt.setString(5, date);
				pstmt.setString(6, tClass);
				pstmt.setString(7, request.getParameter(passengerPrefix + "name"));
				pstmt.setString(8, request.getParameter(passengerPrefix + "gender"));
				pstmt.setInt(9, passengerAge);
				pstmt.setString(10, request.getParameter(passengerPrefix + "preference"));

				pstmt.executeUpdate();
			}

			pw1.println("Tickets Booked Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			pw1.println("<p>Error occurred: " + e.getMessage() + "</p>");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn1 != null)
					conn1.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// Utility method to parse integer safely
	private int safeParseInt(String value) {
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			System.out.println("Failed to parse integer from value: " + value); // Log the incorrect value
			return 0; // You can choose to return a default value or handle it as needed
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Redirect GET request to doPost method
		doPost(request, response);
	}
}
