package irctc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/allservlet")
public class allservlet extends HttpServlet {
	protected void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		rs.setContentType("text/html");
		connection cn = new connection();
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rt = null;
		PrintWriter pw = rs.getWriter();
		try {
			conn = cn.connect_to_db("plf_training", "plf_training_admin", "pff123");
			String qry = "SELECT * FROM stations_tab_05";
			st = conn.prepareStatement(qry);
			rt = st.executeQuery();
			// pw.println("<select id=\"from-station\">");
			pw.println("<option value=\"\">Select station</option>");
			while (rt.next()) {
				String st_name = rt.getString("station_name");
				pw.println("<option value=\"" + st_name + "\">" + st_name + "</option>");
			}
			// pw.println("</select>");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rt != null)
				try {
					rt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if (st != null)
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return;
	}

}
