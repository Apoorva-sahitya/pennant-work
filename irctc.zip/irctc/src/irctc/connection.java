package irctc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connection {

	// TODO Auto-generated method stub
	public Connection connect_to_db(String db, String user, String pwd) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = null;
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection("jdbc:postgresql://192.168.110.48:5432/" + db, user, pwd);
			if (conn != null) {
				System.out.println("connection established");
			} else {
				System.out.println("not connected");
			}

		} catch (Exception e) {
			System.out.print(e);
		}
		return conn;
	}

}
