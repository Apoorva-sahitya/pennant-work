package com.example.Sample.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Sample.contracts.DeptDao;
import com.example.Sample.models.Department;

@Service
public class DeptRepo {

	@Autowired
	DeptDao dao;

	public List<Department> getAllDepts() {
		return (List<Department>) dao.findAll();
	}

	public void save(Department department) {
		dao.save(department);

	}

	public void deleteById(Long id) {
		dao.deleteById(id);

	}

	public Optional<Department> findById(Long id) {
		dao.findById(id);
		return null;
	}
}
