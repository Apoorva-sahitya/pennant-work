package com.example.Sample.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.Sample.models.Department;
import com.example.Sample.repositories.DeptRepo;

@Controller

public class HomeController {

	private DeptRepo deptRepo;

	@Autowired

	public HomeController(DeptRepo repo) {

		this.deptRepo = repo;

	}

	@GetMapping("/depts")

	public String getAllEmployees(Model model) {
		System.out.println("heyy there");
		List<Department> depts = deptRepo.getAllDepts();
		model.addAttribute("depts", depts);
		return "depts";

	}

	// @RequestMapping(value = "/CalladdDept", method = RequestMethod.GET)
	@PostMapping("/CalladdDept")
	public String CallAddDeptJsp() {
		return "addDept";
	}

	@PostMapping("/addDepartment")
	public String addDepartment(@ModelAttribute Department department) {
		deptRepo.save(department);
		return "redirect:/depts";
	}

	@PostMapping("/depts/{id}/delete")
	public String deleteDepartment(@PathVariable Long id, Model model) {
		Optional<Department> departmentOptional = deptRepo.findById(id);
		if (departmentOptional.isPresent()) {
			deptRepo.deleteById(id);
		} else {
			model.addAttribute("errorMessage", "Department not found!");

		}

		// Redirect to the department list page (depts.jsp)
		return "redirect:/depts";
	}

}
