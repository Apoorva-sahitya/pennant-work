package com.example.Sample.contracts;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Sample.models.Department;

@Repository
public interface DeptDao extends CrudRepository<Department, Integer> {

	void deleteById(Long id);

	void findById(Long id);
}
