package com.example.Sample.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dept")
public class Department {

	@Id
	@Column(name = "deptno")
	private int departmentNumber;

	@Column(name = "dname")
	private String departmentName;

	@Column(name = "location")
	private String location;

	public Department() {
	}

	public Department(int departmentNumber, String departmentName, String location) {
		this.departmentNumber = departmentNumber;
		this.departmentName = departmentName;
		this.location = location;
	}

	// Getters and setters
	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	// toString method
	@Override
	public String toString() {
		return "Department{" + "departmentNumber=" + departmentNumber + ", departmentName='" + departmentName + '\''
				+ ", location='" + location + '\'' + '}';
	}
}
