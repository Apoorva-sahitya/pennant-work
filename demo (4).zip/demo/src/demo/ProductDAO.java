package demo;

import java.util.List;

public interface ProductDAO {
	List<products> getAllProducts();
}
