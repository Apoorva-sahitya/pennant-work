package config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages = { "controllers", "Models", "DAO", "Mapper" })
@PropertySource("classpath:db.properties")
public class AppConfig {
	@Autowired

	Environment environment;

	private final String DRIVER = "driver";
	private final String URL = "url";
	private final String USERNAME = "username";
	private final String PASSWORD = "password";

	@Bean

	DataSource dataSource() {
		DriverManagerDataSource dmds = new DriverManagerDataSource();
		dmds.setUrl(environment.getProperty(URL));
		dmds.setUsername(environment.getProperty(USERNAME));
		dmds.setPassword(environment.getProperty(PASSWORD));
		dmds.setDriverClassName(environment.getProperty(DRIVER));

		return dmds;
	}

}
